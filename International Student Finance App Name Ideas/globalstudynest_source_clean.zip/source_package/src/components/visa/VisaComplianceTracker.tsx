import { ArrowUpRight, AlertCircle, CheckCircle, Clock } from "lucide-react";
import { translations } from "../../translations";

interface VisaComplianceTrackerProps {
  language: string;
}

export function VisaComplianceTracker({ language }: VisaComplianceTrackerProps) {
  const t = translations[language];
  
  return (
    <div className="container mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">{t.visaComplianceTracker}</h1>
        <p className="text-gray-600">{t.visaComplianceDescription}</p>
      </div>

      {/* Visa Status Overview */}
      <div className="bg-white p-6 rounded-lg border border-gray-200 mb-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-lg font-semibold text-gray-900">{t.visaStatusOverview}</h2>
          <button className="px-3 py-1 bg-emerald-600 text-white text-sm rounded-md">
            {t.downloadSummary}
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-100">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="h-5 w-5 text-emerald-600" />
              <h3 className="font-medium text-gray-900">{t.visaStatus}</h3>
            </div>
            <p className="text-sm text-gray-600">{t.subclass500}</p>
            <p className="text-sm font-medium text-emerald-700 mt-2">{t.active}</p>
            <div className="mt-3 flex justify-between text-xs text-gray-500">
              <span>{t.issueDate}: March 15, 2023</span>
              <span>{t.expiryDate}: February 28, 2027</span>
            </div>
          </div>
          
          <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-100">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="h-5 w-5 text-emerald-600" />
              <h3 className="font-medium text-gray-900">{t.complianceStatus}</h3>
            </div>
            <p className="text-sm text-gray-600">{t.allRequirementsMet}</p>
            <p className="text-sm font-medium text-emerald-700 mt-2">{t.compliant}</p>
            <div className="mt-3 flex justify-between text-xs text-gray-500">
              <span>{t.lastVerified}: May 15, 2025</span>
              <span>{t.nextVerification}: August 15, 2025</span>
            </div>
          </div>
          
          <div className="p-4 bg-white rounded-lg border border-gray-200">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="h-5 w-5 text-blue-600" />
              <h3 className="font-medium text-gray-900">{t.familyMembers}</h3>
            </div>
            <div className="space-y-2 mt-2">
              <div className="flex justify-between items-center">
                <p className="text-sm text-gray-600">Batbold Ganbold (Primary)</p>
                <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                  {t.verified}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <p className="text-sm text-gray-600">Enkhjargal Ganbold (Spouse)</p>
                <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                  {t.verified}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <p className="text-sm text-gray-600">Munkh Ganbold (Child)</p>
                <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                  {t.verified}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Financial Requirements */}
      <div className="bg-white p-6 rounded-lg border border-gray-200 mb-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-lg font-semibold text-gray-900">{t.financialRequirements}</h2>
          <button className="text-sm text-emerald-600 flex items-center gap-1">
            <span>{t.viewHistory}</span>
            <ArrowUpRight className="h-3 w-3" />
          </button>
        </div>
        
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
              <h3 className="font-medium text-blue-900 mb-2">{t.primaryApplicant}</h3>
              <p className="text-xl font-bold text-blue-700">$21,041</p>
              <p className="text-xs text-blue-600">{t.annualRequirement}</p>
            </div>
            
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
              <h3 className="font-medium text-blue-900 mb-2">{t.spouse}</h3>
              <p className="text-xl font-bold text-blue-700">$7,362</p>
              <p className="text-xs text-blue-600">{t.annualRequirement}</p>
            </div>
            
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
              <h3 className="font-medium text-blue-900 mb-2">{t.child}</h3>
              <p className="text-xl font-bold text-blue-700">$8,296</p>
              <p className="text-xs text-blue-600">{t.annualRequirement}</p>
            </div>
          </div>
          
          <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
            <div className="flex justify-between items-center mb-2">
              <div>
                <h3 className="font-medium text-blue-900">{t.totalRequired}</h3>
                <p className="text-sm text-blue-700">$36,699 AUD</p>
              </div>
              <div className="text-right">
                <h3 className="font-medium text-blue-900">{t.currentBalanceAmount}</h3>
                <p className="text-sm text-blue-700">$42,200 AUD</p>
              </div>
            </div>
            <div className="w-full h-3 bg-blue-200 rounded-full">
              <div className="h-full bg-blue-600 rounded-full" style={{ width: '115%' }}></div>
            </div>
            <p className="mt-2 text-xs text-blue-700 text-right">115% {t.requiredFundsAvailable}</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 border border-gray-200 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-3">{t.acceptedFundingSources}</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-emerald-600" />
                  <span>{t.bankDeposits}</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-emerald-600" />
                  <span>{t.educationLoans}</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-emerald-600" />
                  <span>{t.scholarships}</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-emerald-600" />
                  <span>{t.financialSponsorship}</span>
                </li>
              </ul>
            </div>
            
            <div className="p-4 border border-gray-200 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-3">{t.yourFundingSources}</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <p className="text-sm text-gray-600">Commonwealth Bank Savings</p>
                  <p className="text-sm font-medium text-gray-900">$24,350 AUD</p>
                </div>
                <div className="flex justify-between items-center">
                  <p className="text-sm text-gray-600">Term Deposit</p>
                  <p className="text-sm font-medium text-gray-900">$15,000 AUD</p>
                </div>
                <div className="flex justify-between items-center">
                  <p className="text-sm text-gray-600">University Scholarship</p>
                  <p className="text-sm font-medium text-gray-900">$2,850 AUD</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Health Insurance */}
      <div className="bg-white p-6 rounded-lg border border-gray-200 mb-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-lg font-semibold text-gray-900">{t.healthInsurance}</h2>
          <button className="text-sm text-emerald-600 flex items-center gap-1">
            <span>{t.manageCoverage}</span>
            <ArrowUpRight className="h-3 w-3" />
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-100 mb-4">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-medium text-gray-900">{t.oshcStatus}</h3>
                <span className="text-xs px-2 py-1 rounded-full bg-emerald-100 text-emerald-800">
                  {t.active}
                </span>
              </div>
              <p className="text-sm text-gray-600">{t.provider}: Medibank</p>
              <p className="text-sm text-gray-600">{t.policyNumber}: OSHC-2023-78945612</p>
              <div className="mt-3 flex justify-between text-xs text-gray-500">
                <span>{t.startDate}: March 15, 2023</span>
                <span>{t.expiryDate}: March 15, 2026</span>
              </div>
            </div>
            
            <div className="p-4 border border-gray-200 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-3">{t.coverageDetails}</h3>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <p className="text-sm text-gray-600">{t.coverageType}</p>
                  <p className="text-sm font-medium text-gray-900">{t.familyCoverage}</p>
                </div>
                <div className="flex justify-between items-center">
                  <p className="text-sm text-gray-600">{t.hospitalCover}</p>
                  <p className="text-sm font-medium text-gray-900">100%</p>
                </div>
                <div className="flex justify-between items-center">
                  <p className="text-sm text-gray-600">{t.generalTreatment}</p>
                  <p className="text-sm font-medium text-gray-900">85%</p>
                </div>
                <div className="flex justify-between items-center">
                  <p className="text-sm text-gray-600">{t.pharmaceuticals}</p>
                  <p className="text-sm font-medium text-gray-900">{t.pbs}</p>
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <div className="p-4 border border-gray-200 rounded-lg mb-4">
              <h3 className="font-medium text-gray-900 mb-3">{t.coveredFamilyMembers}</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm font-medium text-gray-900">Batbold Ganbold</p>
                    <p className="text-xs text-gray-500">{t.primary}</p>
                  </div>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    {t.covered}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm font-medium text-gray-900">Enkhjargal Ganbold</p>
                    <p className="text-xs text-gray-500">{t.spouse}</p>
                  </div>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    {t.covered}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm font-medium text-gray-900">Munkh Ganbold</p>
                    <p className="text-xs text-gray-500">{t.dependent}</p>
                  </div>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    {t.covered}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="p-4 border border-gray-200 rounded-lg">
              <div className="flex items-center gap-2 mb-3">
                <AlertCircle className="h-5 w-5 text-amber-500" />
                <h3 className="font-medium text-gray-900">{t.upcomingRenewal}</h3>
              </div>
              <p className="text-sm text-gray-600 mb-3">{t.renewalReminder}</p>
              <div className="flex justify-between items-center">
                <p className="text-sm text-gray-600">{t.renewalDate}</p>
                <p className="text-sm font-medium text-gray-900">March 15, 2026</p>
              </div>
              <div className="flex justify-between items-center">
                <p className="text-sm text-gray-600">{t.estimatedCost}</p>
                <p className="text-sm font-medium text-gray-900">$2,800 AUD</p>
              </div>
              <button className="mt-4 w-full px-3 py-2 bg-emerald-600 text-white text-sm rounded-md">
                {t.setRenewalReminder}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Enrollment Verification */}
      <div className="bg-white p-6 rounded-lg border border-gray-200 mb-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-lg font-semibold text-gray-900">{t.enrollmentVerification}</h2>
          <button className="text-sm text-emerald-600 flex items-center gap-1">
            <span>{t.uploadDocuments}</span>
            <ArrowUpRight className="h-3 w-3" />
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-100 mb-4">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-medium text-gray-900">{t.currentEnrollment}</h3>
                <span className="text-xs px-2 py-1 rounded-full bg-emerald-100 text-emerald-800">
                  {t.verified}
                </span>
              </div>
              <p className="text-sm text-gray-600">{t.institution}: University of Melbourne</p>
              <p className="text-sm text-gray-600">{t.program}: Master of Business Administration</p>
              <p className="text-sm text-gray-600">{t.studyLoad}: Full-time (4 courses)</p>
              <div className="mt-3 flex justify-between text-xs text-gray-500">
                <span>{t.currentSemester}: Semester 1, 2025</span>
                <span>{t.expectedCompletion}: December 2026</span>
              </div>
            </div>
            
            <div className="p-4 border border-gray-200 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-3">{t.visaStudyRequirements}</h3>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-emerald-600" />
                  <p className="text-sm text-gray-600">{t.maintainFullTimeEnrollment}</p>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-emerald-600" />
                  <p className="text-sm text-gray-600">{t.attendClassesRegularly}</p>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-emerald-600" />
                  <p className="text-sm text-gray-600">{t.maintainSatisfactoryProgress}</p>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-emerald-600" />
                  <p className="text-sm text-gray-600">{t.notifyAddressChange}</p>
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <div className="p-4 border border-gray-200 rounded-lg mb-4">
              <h3 className="font-medium text-gray-900 mb-3">{t.verificationDocuments}</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <svg className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    <p className="text-sm font-medium text-gray-900">Confirmation of Enrollment.pdf</p>
                  </div>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    {t.verified}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <svg className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    <p className="text-sm font-medium text-gray-900">Course Registration.pdf</p>
                  </div>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    {t.verified}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <svg className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    <p className="text-sm font-medium text-gray-900">Tuition Payment Receipt.pdf</p>
                  </div>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    {t.verified}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="p-4 border border-gray-200 rounded-lg">
              <div className="flex items-center gap-2 mb-3">
                <Clock className="h-5 w-5 text-blue-600" />
                <h3 className="font-medium text-gray-900">{t.upcomingVerifications}</h3>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <p className="text-sm text-gray-600">{t.semesterEnrollment}</p>
                  <p className="text-sm font-medium text-gray-900">July 15, 2025</p>
                </div>
                <div className="flex justify-between items-center">
                  <p className="text-sm text-gray-600">{t.academicProgress}</p>
                  <p className="text-sm font-medium text-gray-900">August 15, 2025</p>
                </div>
                <div className="flex justify-between items-center">
                  <p className="text-sm text-gray-600">{t.attendanceVerification}</p>
                  <p className="text-sm font-medium text-gray-900">September 30, 2025</p>
                </div>
              </div>
              <button className="mt-4 w-full px-3 py-2 bg-emerald-600 text-white text-sm rounded-md">
                {t.setVerificationReminders}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Document Management */}
      <div className="bg-white p-6 rounded-lg border border-gray-200">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-lg font-semibold text-gray-900">{t.documentManagement}</h2>
          <div className="flex gap-2">
            <button className="px-3 py-1 bg-gray-200 text-gray-700 text-sm rounded-md">
              {t.organize}
            </button>
            <button className="px-3 py-1 bg-emerald-600 text-white text-sm rounded-md">
              {t.uploadNew}
            </button>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead>
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{t.documentName}</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{t.category}</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{t.uploadDate}</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{t.expiryDate}</th>
                <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">{t.status}</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t.actions}</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              <tr>
                <td className="px-4 py-4 whitespace-nowrap">
                  <div className="flex items-center gap-2">
                    <svg className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    <p className="text-sm font-medium text-gray-900">Student Visa Grant Notice.pdf</p>
                  </div>
                </td>
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">Visa Documents</td>
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">March 15, 2023</td>
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">February 28, 2027</td>
                <td className="px-4 py-4 whitespace-nowrap text-center">
                  <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    {t.valid}
                  </span>
                </td>
                <td className="px-4 py-4 whitespace-nowrap text-right text-sm">
                  <button className="text-emerald-600 hover:text-emerald-800">{t.view}</button>
                </td>
              </tr>
              <tr>
                <td className="px-4 py-4 whitespace-nowrap">
                  <div className="flex items-center gap-2">
                    <svg className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    <p className="text-sm font-medium text-gray-900">OSHC Policy Certificate.pdf</p>
                  </div>
                </td>
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">Health Insurance</td>
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">March 15, 2023</td>
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">March 15, 2026</td>
                <td className="px-4 py-4 whitespace-nowrap text-center">
                  <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    {t.valid}
                  </span>
                </td>
                <td className="px-4 py-4 whitespace-nowrap text-right text-sm">
                  <button className="text-emerald-600 hover:text-emerald-800">{t.view}</button>
                </td>
              </tr>
              <tr>
                <td className="px-4 py-4 whitespace-nowrap">
                  <div className="flex items-center gap-2">
                    <svg className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    <p className="text-sm font-medium text-gray-900">Bank Statement - Commonwealth.pdf</p>
                  </div>
                </td>
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">Financial Evidence</td>
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">April 10, 2025</td>
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">July 10, 2025</td>
                <td className="px-4 py-4 whitespace-nowrap text-center">
                  <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    {t.valid}
                  </span>
                </td>
                <td className="px-4 py-4 whitespace-nowrap text-right text-sm">
                  <button className="text-emerald-600 hover:text-emerald-800">{t.view}</button>
                </td>
              </tr>
              <tr>
                <td className="px-4 py-4 whitespace-nowrap">
                  <div className="flex items-center gap-2">
                    <svg className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    <p className="text-sm font-medium text-gray-900">Confirmation of Enrollment.pdf</p>
                  </div>
                </td>
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">Enrollment</td>
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">May 15, 2025</td>
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">July 15, 2025</td>
                <td className="px-4 py-4 whitespace-nowrap text-center">
                  <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    {t.valid}
                  </span>
                </td>
                <td className="px-4 py-4 whitespace-nowrap text-right text-sm">
                  <button className="text-emerald-600 hover:text-emerald-800">{t.view}</button>
                </td>
              </tr>
              <tr>
                <td className="px-4 py-4 whitespace-nowrap">
                  <div className="flex items-center gap-2">
                    <svg className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    <p className="text-sm font-medium text-gray-900">Passport - Batbold.pdf</p>
                  </div>
                </td>
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">Identification</td>
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">January 10, 2023</td>
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">January 10, 2028</td>
                <td className="px-4 py-4 whitespace-nowrap text-center">
                  <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    {t.valid}
                  </span>
                </td>
                <td className="px-4 py-4 whitespace-nowrap text-right text-sm">
                  <button className="text-emerald-600 hover:text-emerald-800">{t.view}</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
